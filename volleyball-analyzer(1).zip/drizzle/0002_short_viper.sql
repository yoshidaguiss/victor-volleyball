ALTER TABLE `matches` MODIFY COLUMN `scoreHome` json;--> statement-breakpoint
ALTER TABLE `matches` MODIFY COLUMN `scoreAway` json;